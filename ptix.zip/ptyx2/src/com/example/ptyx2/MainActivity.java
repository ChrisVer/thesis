package com.example.ptyx2;



import android.support.v7.app.ActionBarActivity;
import android.app.Dialog;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;
 


/*requestWindowFeature(Window.FEATURE_NO_TITLE);
getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);*/

public class MainActivity extends ActionBarActivity     {
	
	public static final String DEFAULT="N/A";

	ImageView exitbtn,ok,cancel,ready ;
	Dialog custom;
	FragmentManager manager;
	
	int option = 0;

	 TextView userNameTxtview;

	 TextView passTxtview;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		
		
		requestWindowFeature( Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
		setContentView(R.layout.activity_main);
		
		
		manager = getFragmentManager();
		
		
		
		addA();
		
			
	}
	
	
	
	public void addA()  // MainMenu
	{
		FragA F1 = new FragA();
		FragmentTransaction transaction = manager.beginTransaction();
		transaction.add(R.id.group,F1,"A");
		transaction.commit();
	}
	
	public void replaceAwithB(View v)  // Credits
	{
		FragB F2 = new FragB();
		FragmentTransaction transaction = manager.beginTransaction();
		transaction.replace(R.id.group, F2, "B");
		transaction.commit();
	}//addB
	
	public void replaceBwithA(View v) // otan patithei to back toy Credits
	{
		FragA F1 = new FragA();
		FragmentTransaction transaction = manager.beginTransaction();
		transaction.replace(R.id.group, F1, "A");
		transaction.commit();
	}
	
	public void closeapp(View v) // Exit
	{
		finish(); 
		
	}
	
	public void replaceCwithA(View v) // otan patithei to back toy C fragment
	{
		FragA F1 = new FragA();
		FragmentTransaction transaction = manager.beginTransaction();
		transaction.replace(R.id.group, F1, "A");
		transaction.commit();
	}
	
	public void replaceAwithC(View v) // Play pressed
	{
		FragC F3 = new FragC();
		FragmentTransaction transaction = manager.beginTransaction();
		transaction.replace(R.id.group, F3, "C");
		transaction.commit();
	}
	
	public void replaceCwithD(View v) // time trial pressed
	{
		FragD F4 = new FragD();
		FragmentTransaction transaction = manager.beginTransaction();
		transaction.replace(R.id.group, F4, "D");
		transaction.commit();
	}
	
	public void replaceDwithC(View v) //Back of time trials pressed 
	{
		FragC F3 = new FragC();
		FragmentTransaction transaction = manager.beginTransaction();
		transaction.replace(R.id.group, F3, "C");
		transaction.commit();
	}

	
	public void replaceEwithC(View v) // back of mini games
	{
		FragC F3 = new FragC();
		FragmentTransaction transaction = manager.beginTransaction();
		transaction.replace(R.id.group, F3, "C");
		transaction.commit();
	}

	public void replaceCwithE(View v) // press mini Games
	{
		FragE F5 = new FragE();
		FragmentTransaction transaction = manager.beginTransaction();
		transaction.replace(R.id.group, F5, "C");
		transaction.commit();
	}
	public void replaceDwithF(View v) // time trial - are you sure ok  was pressed
	{
		FragF FF1 = new FragF();
		FragmentTransaction transaction = manager.beginTransaction();
		transaction.replace(R.id.group, FF1, "Start");
		transaction.commit();
		
		// easy was pressed
		
		//option = 1 ; // 1 = easy
		
	}

	public void replaceFwithD(View v)   //  cancel was pressed
	{
		FragD F4 = new FragD();
		FragmentTransaction transaction = manager.beginTransaction();
		transaction.replace(R.id.group, F4, "Cancel");
		transaction.commit();
		
	}
	
	
	public void replaceDwithF2 (View v) // Medium was Pressed
	{
		FragF2 FF2 = new FragF2();
		FragmentTransaction transaction = manager.beginTransaction();
		transaction.replace(R.id.group, FF2, "FF2");
		transaction.commit();
	}
	
	
	public void replaceF2withD(View v)   // Press cancel
	{
		FragD F4 = new FragD();
		FragmentTransaction transaction = manager.beginTransaction();
		transaction.replace(R.id.group, F4, "Cancel");
		transaction.commit();
		
	}
	
	public void replaceDwithF3(View v)   // Hard was pressed
	{
		FragF3 FF3 = new FragF3();
		FragmentTransaction transaction = manager.beginTransaction();
		transaction.replace(R.id.group, FF3, "FF3");
		transaction.commit();
		
	}
	
	public void replaceF3withD(View v)   // Press cancel
	{
		FragD D = new FragD();
		FragmentTransaction transaction = manager.beginTransaction();
		transaction.replace(R.id.group, D, "Cancel");
		transaction.commit();
		
	}
	
	
	
	public void StartEasy(View v) // Time Trial - ok of  Easy pressed
	{
		
		Intent intent = new Intent(this, Easy.class);
		startActivity(intent);
	}
	
	public void highscores(View v) // 
	{
		
		Intent intent = new Intent(this, HighScoresActivity.class);
		startActivity(intent);
	}
	

	public void StartMedium (View v) // ok of medium was pressed
	{
		
		Intent intent = new Intent(this, Medium.class);
		startActivity(intent);
	}
	public void StartHard (View v) // ok of medium was pressed
	{
		
		
		Intent intent = new Intent(this, Hard.class);
		startActivity(intent);
	}
	
	
/*public void load(View view) {
		
		SharedPreferences sharedPreferences = getSharedPreferences("MyData", 0);
		String name = sharedPreferences.getString("high1", "");
		//String password = sharedPreferences.getString("password", "");
		
		if(name.equals(DEFAULT)) //|| password.equals(DEFAULT))
		{
			Toast.makeText(this, "NO Data was found", Toast.LENGTH_LONG).show();
		}
		else 
		{
			Toast.makeText(this, "Data was LOADED ", Toast.LENGTH_LONG).show();
			userNameTxtview.setText(name);
			//passTxtview.setText(password);
		}
	}
	*/
	
	@Override
	public void onBackPressed() {
	}


	
		
	


	


	
}





