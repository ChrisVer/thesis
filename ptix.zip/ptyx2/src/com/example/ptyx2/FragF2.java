package com.example.ptyx2;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;

import android.widget.Button;

public class FragF2 extends Fragment implements OnClickListener{

	//Button back;
	
	
	
	
	 @Override
	public View onCreateView  (LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		//return super.onCreateView(inflater, container, savedInstanceState);
	
		View v= inflater.inflate(R.layout.frag_f_2_layout,  container, false);
		return v;
	
	 }




	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		//back = (Button) v.findViewById(R.id.Backbutton);
		//back.setOnClickListener(this);
		
		
	}
}
