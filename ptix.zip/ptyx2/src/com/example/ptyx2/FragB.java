package com.example.ptyx2;



import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;

import android.widget.Button;
import android.widget.TextView;

public class FragB extends Fragment implements OnClickListener{

	 //TextView nai;
	 //TextView pointstext;

	 TextView high , bbb ;    //, //userNameTxtview;


	//Button back;
	
	
	
	
	 @Override
	public View onCreateView  (LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		//return super.onCreateView(inflater, container, savedInstanceState);
	
		View v= inflater.inflate(R.layout.frag_b_layout,  container, false);
		
		high = (TextView)v.findViewById(R.id.high);
		
		bbb =  (TextView) getActivity().findViewById(R.id.high);
		
		String MSG = bbb.getText().toString();
		 
		 high.setText(MSG);
		
		
		
		return v;
	
	 }




	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		//back = (Button) v.findViewById(R.id.Backbutton);
		//back.setOnClickListener(this);
		
		
	}
}
