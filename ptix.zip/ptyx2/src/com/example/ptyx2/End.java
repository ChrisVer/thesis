package com.example.ptyx2;

import android.app.Fragment;
import android.content.SharedPreferences;

import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.WebView.FindListener;
import android.widget.Button;
import android.widget.TextView;



public class End extends Fragment implements OnClickListener{


	int points;
	
 TextView nai, pointstext;


	 public View onCreateView  (LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		//return super.onCreateView(inflater, container, savedInstanceState);
	
		 View  v;
		 v= inflater.inflate(R.layout.end_layout,  container, false);
		 
		 
		 /*String strtext=getArguments().getString("message");
		 
		 nai.setText(strtext);*/
		 
		 nai = (TextView)v.findViewById(R.id.textView2);
		 
		 pointstext =  (TextView) getActivity().findViewById(R.id.textView2);
		 
		 
		 String MSG = pointstext.getText().toString();
		 
		 nai.setText(MSG);
		 
		 
		 
		 
		 
		return v;
		
		
	
	 }




	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
		
		
		
	}
}