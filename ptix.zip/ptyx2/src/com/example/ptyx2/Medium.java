package com.example.ptyx2;

import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.xml.transform.Templates;

import android.R.anim;
import android.R.string;
import android.support.v7.app.ActionBarActivity;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.Image;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.opengl.Visibility;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Base64;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class Medium extends ActionBarActivity  implements OnClickListener
{
	
	
	
	int arePigs = 0;
	int areFishes = 0;
	int areElephants = 0;
	int areFrogs = 0;
	int areDogs = 0;
	int areSharks = 0;
	int arePandas = 0;
	
	int animaloption = 0; // random animal choice

	android.app.FragmentManager mymanager;
	
	TextView xronos, pointstext;
	
	GridView myGrid;
	
	MediaPlayer mp;
	int correct = 0;
	SoundPool sp;
	
	private static final String FORMAT = "%02d:%02d";
	
	int seconds , minutes, k, i = 0, points = 0;
	
	ImageView test2,pig,fish;
	//ImageView[] test2;
	
	
	
	private static final Random rgenerator = new Random();

	private static final Integer[] mImageIds = 
	    { 
		 
		
		R.drawable.beaver,
		R.drawable.bird,
		R.drawable.bug,
		
		R.drawable.cat,
		
		R.drawable.dog,
		R.drawable.dolphin,
		
		R.drawable.elephant, 
		
		R.drawable.fish,
		R.drawable.fish2,
		R.drawable.fish3,
		R.drawable.frog,
		
		R.drawable.gorilla,
		
		R.drawable.hamster,
		
		R.drawable.hippo2,
		
		R.drawable.lion,
		
		R.drawable.panda,
		R.drawable.penguin,
		R.drawable.pig,
		
		R.drawable.rooster,
		
		R.drawable.seaturtle,
		R.drawable.shark,
		R.drawable.sheep,
		
		R.drawable.turtle
		};

	private static final int numrows = 3;

	private static final int numcols = 6;
	
	Random generator = new Random();
	
	int gourounia = 0, psaria =0 , elef =0 , batr = 0 , skil = 0 ;
	
	int[][] pinakas = new int[3][6];
	TableLayout table;
	ImageView im[][] =  new ImageView[3][6];
	 
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		requestWindowFeature( Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
		
		setContentView(R.layout.activity_medium);
		
		
		
		mymanager = getFragmentManager();
		
	
		mp = MediaPlayer.create(this, R.raw.correct_midhigh);
		
		sp = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);
		correct = sp.load(this, R.raw.correct_midhigh, 1);
		
		
		pointstext=(TextView)findViewById(R.id.textView2);
		
		table = (TableLayout) findViewById(R.id.table);
		
		for (int row = 0; row <numrows; row ++)
		{
			TableRow tablerow = new TableRow(this);
			table.addView(tablerow);
			
			for (int col = 0; col<numcols;col++)
			{
				 
				 int randomIndex = generator.nextInt(mImageIds.length);
				 im[row][col] = new ImageView(this);
				 im[row][col].setBackgroundResource(mImageIds[randomIndex]);
				 im[row][col].setOnClickListener(this);
				 
				 
			     tablerow.addView(im[row][col]);
				 
			     if (mImageIds[randomIndex] == R.drawable.beaver) 
				 {	 
			    	 im[row][col].setTag("beaver");
				 }
			     if (mImageIds[randomIndex] == R.drawable.bird) 
				 {	 
			    	 im[row][col].setTag("bird");
				 }
			     if (mImageIds[randomIndex] == R.drawable.bug) 
				 {	 
			    	 im[row][col].setTag("bug");
				 }
			     if (mImageIds[randomIndex] == R.drawable.cat) 
				 {	 
			    	 im[row][col].setTag("cat");
				 }
			     if (mImageIds[randomIndex] == R.drawable.dolphin) 
				 {	 
			    	 im[row][col].setTag("dolphin");
				 }
			     if (mImageIds[randomIndex] == R.drawable.fish2) 
				 {	 
			    	 im[row][col].setTag("fish2");
				 }
			     if (mImageIds[randomIndex] == R.drawable.fish3) 
				 {	 
			    	 im[row][col].setTag("fish3");
				 }
			     if (mImageIds[randomIndex] == R.drawable.gorilla) 
				 {	 
			    	 im[row][col].setTag("gorilla");
				 }
			     if (mImageIds[randomIndex] == R.drawable.hamster) 
				 {	 
			    	 im[row][col].setTag("hamster");
				 }
			     if (mImageIds[randomIndex] == R.drawable.hippo2) 
				 {	 
			    	 im[row][col].setTag("hippo2");
				 }
			     if (mImageIds[randomIndex] == R.drawable.lion) 
				 {	 
			    	 im[row][col].setTag("lion");
				 }
			     if (mImageIds[randomIndex] == R.drawable.panda) 
				 {	 
			    	 im[row][col].setTag("panda");
			    	 arePandas ++;
			    	 im[row][col].setOnClickListener(this);
			    	 
				 }
			     if (mImageIds[randomIndex] == R.drawable.penguin) 
				 {	 
			    	 im[row][col].setTag("penguin");
				 }
			     if (mImageIds[randomIndex] == R.drawable.rooster) 
				 {	 
			    	 im[row][col].setTag("rooster");
				 }
			     if (mImageIds[randomIndex] == R.drawable.seaturtle) 
				 {	 
			    	 im[row][col].setTag("seaturtle");
				 }
			     if (mImageIds[randomIndex] == R.drawable.shark) 
				 {	 
			    	 im[row][col].setTag("shark");
			    	 areSharks ++;
			    	 im[row][col].setOnClickListener(this);
				 }
			     if (mImageIds[randomIndex] == R.drawable.sheep) 
				 {	 
			    	 im[row][col].setTag("sheep");
				 }
			     if (mImageIds[randomIndex] == R.drawable.turtle) 
				 {	 
			    	 im[row][col].setTag("turtle");
				 }
			     
			//------------------------------------------------------------------------     
			     
			    
			     if (mImageIds[randomIndex] == R.drawable.pig) 
				 {	 
			    	 
			    	 im[row][col].setTag("pig");
					 arePigs ++;
					 im[row][col].setOnClickListener(this);
				 }
				 if (mImageIds[randomIndex] == R.drawable.fish) 
				 {	 
					 im[row][col].setTag("fish");
					 areFishes ++;
					 im[row][col].setOnClickListener(this);
				 }
				 if (mImageIds[randomIndex] == R.drawable.elephant) 
				 {	 
					 im[row][col].setTag("elephant");
					 areElephants ++;
					 im[row][col].setOnClickListener(this);
				 }
				 if (mImageIds[randomIndex] == R.drawable.frog) 
				 {	
					 im[row][col].setTag("frog");
					 areFrogs ++;
					 im[row][col].setOnClickListener(this);
				 }
				 if (mImageIds[randomIndex] == R.drawable.dog) 
				 {	
					 im[row][col].setTag("dog");
					 areDogs ++;
					 im[row][col].setOnClickListener(this);
					 
				 }
				 
				 
				 	
		   
		       }// for loop
  	
	        }
		
		xronos=(TextView)findViewById(R.id.textView1);
		 
		 new CountDownTimer(10000, 1000) { // adjust the milli seconds here

		        public void onTick(long millisUntilFinished) 
		        {

						        	xronos.setText(""+String.format(FORMAT,
						                    
						TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) - TimeUnit.HOURS.toMinutes(
						                    TimeUnit.MILLISECONDS.toHours(millisUntilFinished)),
						  TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) - TimeUnit.MINUTES.toSeconds(
						                      TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished))));    
						        	
						        	
						        	
		        }

		        public void onFinish() {
		        	//xronos.setText();
		        	
		        	pointstext.setText(String.valueOf(points));
		        	pointstext.setVisibility(View.GONE);
		        	
		        	table.removeAllViewsInLayout();
		        	
		        	mymanager = getFragmentManager();
		        	End e1 = new End();
		    		FragmentTransaction transaction2 = mymanager.beginTransaction();
		    		transaction2.add(R.id.group2, e1, "end");
		    		transaction2.commit();
		    		
		        		        	
		        }
		     }.start(); 
		     
		     // -------- kodikas pou ekteleitai asxeta apo ti n epilogi toy xristi
		     
		     
		     
		     // -------- kodikas poy ekteleitai analoga me ti epilexthike
		
		     
		     
		    animaloption = generator.nextInt(7);
		     
		    
		      
		     // 0 = pig , 1 = fish , 2 = elephant, 3 = 
		     
		if (animaloption == 0) // an epilexthike na psaxnv gia pigs     
		{ 
			Toast.makeText(getApplicationContext(), "Collect as many PIGS you can before the time goes off !" , Toast.LENGTH_SHORT).show();
			
			// se periptosi poy arxika den exei sxediastei kanena pig
			
			if (arePigs == 0)
				{
					int stiles = generator.nextInt(numcols);
					int grammes = generator.nextInt(numrows);
					
					 im[grammes][stiles].setBackgroundResource(R.drawable.pig);
					 im[grammes][stiles].setOnClickListener(this);
					 im[grammes][stiles].setTag("pig");
				}
			
		}
		
		if (animaloption == 1) // an epilexthe na psaxnv fishes
		{
			Toast.makeText(getApplicationContext(), "Collect as many FISHES you can before the time goes off !" , Toast.LENGTH_SHORT).show();
			
			// se periptosi poy arxika den exei sxediastei kanena fish
			
			if (areFishes == 0)
			{
				int stiles = generator.nextInt(numcols);
				int grammes = generator.nextInt(numrows);
				
				 im[grammes][stiles].setBackgroundResource(R.drawable.fish);
				 im[grammes][stiles].setOnClickListener(this);
				 im[grammes][stiles].setTag("fish");
			}
			
			
		}
	
		if (animaloption == 2) // an epilexthike na psaxnv gia elephants     
		{ 
			Toast.makeText(getApplicationContext(), "Collect as many ELEPHANTS you can before the time goes off !" , Toast.LENGTH_SHORT).show();
			 
			// se periptosi poy arxika den exei sxediastei kanena elephant
			
			if (areElephants == 0)
				{
					int stiles = generator.nextInt(numcols);
					int grammes = generator.nextInt(numrows);
					
					 im[grammes][stiles].setBackgroundResource(R.drawable.elephant);
					 im[grammes][stiles].setOnClickListener(this);
					 im[grammes][stiles].setTag("elephant");
				}
		}
		if (animaloption == 3) // an epilexthike na psaxnv gia frogs     
		{ 
			Toast.makeText(getApplicationContext(), "Collect as many FROGS you can before the time goes off !" , Toast.LENGTH_SHORT).show();
			 
			// se periptosi poy arxika den exei sxediastei kanena elephant
			
			if (areFrogs == 0)
				{
					int stiles = generator.nextInt(numcols);
					int grammes = generator.nextInt(numrows);
					
					 im[grammes][stiles].setBackgroundResource(R.drawable.frog);
					 im[grammes][stiles].setOnClickListener(this);
					 im[grammes][stiles].setTag("frog");
				}
		}
		
		
		if (animaloption == 4) // an epilexthike na psaxnv gia dogs     
		{ 
			Toast.makeText(getApplicationContext(), "Collect as many DOGS you can before the time goes off !" , Toast.LENGTH_SHORT).show();
			 
			// se periptosi poy arxika den exei sxediastei kanena elephant
			
			if (areDogs == 0)
				{
					int stiles = generator.nextInt(numcols);
					int grammes = generator.nextInt(numrows);
					
					 im[grammes][stiles].setBackgroundResource(R.drawable.dog);
					 im[grammes][stiles].setOnClickListener(this);
					 im[grammes][stiles].setTag("dog");
				}
		}
		
		
		if (animaloption == 5) // an epilexthike na psaxnv gia pandas     
		{ 
			Toast.makeText(getApplicationContext(), "Collect as many PANDAS you can before the time goes off !" , Toast.LENGTH_SHORT).show();
			 
			// se periptosi poy arxika den exei sxediastei kanena elephant
			
			if (arePandas == 0)
				{
					int stiles = generator.nextInt(numcols);
					int grammes = generator.nextInt(numrows);
					
					 im[grammes][stiles].setBackgroundResource(R.drawable.panda);
					 im[grammes][stiles].setOnClickListener(this);
					 im[grammes][stiles].setTag("panda");
				}
		}
		
		if (animaloption == 6) // an epilexthike na psaxnv gia sharks     
		{ 
			Toast.makeText(getApplicationContext(), "Collect as many SHARKS you can before the time goes off !" , Toast.LENGTH_SHORT).show();
			 
			// se periptosi poy arxika den exei sxediastei kanena elephant
			
			if (areSharks == 0)
				{
					int stiles = generator.nextInt(numcols);
					int grammes = generator.nextInt(numrows);
					
					 im[grammes][stiles].setBackgroundResource(R.drawable.shark);
					 im[grammes][stiles].setOnClickListener(this);
					 im[grammes][stiles].setTag("shark");
				}
		}
		
		
		  }//onCreate
	
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.easy, menu);
		
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}




	@Override
	public void onClick(View v ) {
		
		
		String tag =(String)v.getTag();
		int randomIndex = generator.nextInt(mImageIds.length);
		

		if(tag!=null && tag.equals("pig"))
		{
			if (animaloption == 0)
			
			{  //showCustomToast();
			
			 points = points + 10 ;
			 sp.play(correct, 1, 1, 0, 0, 1);
			 
			//Toast.makeText(getAppl icationContext(), "you hit pig" , Toast.LENGTH_SHORT).show();
			// int fores = generator.nextInt(2);
			 //fores++;
			 
			  
			 v.setBackgroundResource(mImageIds[randomIndex]);
			 v.setOnClickListener(this);
			
			// for (int br = 0 ; br<fores; br++)
			// {
					 int stiles = generator.nextInt(numcols);
					 int grammes = generator.nextInt(numrows);
				
					 im[grammes][stiles].setBackgroundResource(R.drawable.pig);
					 im[grammes][stiles].setOnClickListener(this);
					 im[grammes][stiles].setTag("pig");
			
			//}
		    }
			else 
				{ points = points - 2 ;
			     Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
				}
		}
		
		
		
		
			
			
			if(tag!=null && tag.equals("dog"))
			{
				if (animaloption == 4)
				{//showCustomToast();
				
				 points = points + 10 ;
				 sp.play(correct, 1, 1, 0, 0, 1);
				 
				
				//Toast.makeText(getAppl icationContext(), "you hit pig" , Toast.LENGTH_SHORT).show();
				// int fores = generator.nextInt(2);
				// fores++;
				 
				  
				 v.setBackgroundResource(mImageIds[randomIndex]);
				 v.setOnClickListener(this);
				
				// for (int br = 0 ; br<fores; br++)
				// {
						 int stiles = generator.nextInt(numcols);
						 int grammes = generator.nextInt(numrows);
					
						 im[grammes][stiles].setBackgroundResource(R.drawable.dog);
						 im[grammes][stiles].setOnClickListener(this);
						 im[grammes][stiles].setTag("dog");
				
				// }
				}
						 else 
							{ points = points - 2 ;
						     Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
							}
				
			}
			 
		
		  
		
		if(tag!=null && tag.equals("frog")) 
		{
			if (animaloption == 3) 
			{ 
				//showCustomToast();
			
				
				 points = points + 10 ;
				 sp.play(correct, 1, 1, 0, 0, 1);
				 
				//Toast.makeText(getAppl icationContext(), "you hit pig" , Toast.LENGTH_SHORT).show();
				// int fores = generator.nextInt(2);
				// fores++;
				 
				  
				 v.setBackgroundResource(mImageIds[randomIndex]);
				 v.setOnClickListener(this);
				
				// for (int br = 0 ; br<fores; br++)
				// {
						 int stiles = generator.nextInt(numcols);
						 int grammes = generator.nextInt(numrows);
					
						 im[grammes][stiles].setBackgroundResource(R.drawable.frog);
						 im[grammes][stiles].setOnClickListener(this);
						 im[grammes][stiles].setTag("frog");
				
				// }
			} 
			points = points - 2 ;
			Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
		}
		
		
		if(tag!=null && tag.equals("elephant")) 
		{
			if (animaloption == 2)
		{
			//showCustomToast();
			
			 points = points + 10 ;
			 sp.play(correct, 1, 1, 0, 0, 1);
			 
			//Toast.makeText(getAppl icationContext(), "you hit pig" , Toast.LENGTH_SHORT).show();
			// int fores = generator.nextInt(2);
			// fores++;
			 
			  
			 v.setBackgroundResource(mImageIds[randomIndex]);
			 v.setOnClickListener(this);
			
		//	 for (int br = 0 ; br<fores; br++)
		//	 {
					 int stiles = generator.nextInt(numcols);
					 int grammes = generator.nextInt(numrows);
				
					 im[grammes][stiles].setBackgroundResource(R.drawable.elephant);
					 im[grammes][stiles].setOnClickListener(this);
					 im[grammes][stiles].setTag("elephant");
			
		//	 }
		}
			 else 
				{ points = points - 2 ;
			     Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
				}
	
		}
		
		if(tag!=null && tag.equals("beaver"))
		{
			 points = points - 2;
			 Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
			 //v.setBackgroundResource(mImageIds[randomIndex]);
			 v.setOnClickListener(this);
			
		}
		if(tag!=null && tag.equals("bird"))
		{
			
			points = points - 2;
			Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
			 //v.setBackgroundResource(mImageIds[randomIndex]);
			 v.setOnClickListener(this);
			
		}
		if(tag!=null && tag.equals("bug"))
		{
			Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
			points = points - 2;
			 //v.setBackgroundResource(mImageIds[randomIndex]);
			 v.setOnClickListener(this);
			
		}
		if(tag!=null && tag.equals("cat"))
		{
			
			points = points - 2;
			Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
			 //v.setBackgroundResource(mImageIds[randomIndex]);
			 v.setOnClickListener(this);
			
		}
		if(tag!=null && tag.equals("dolphin"))
		{
			Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
			points = points - 2;
			 //v.setBackgroundResource(mImage Ids[randomIndex]);
			 v.setOnClickListener(this);
			
		}
		if(tag!=null && tag.equals("fish"))
		{
			if (animaloption == 1)
			{
				//showCustomToast();
				
				 points = points + 10 ;
				 sp.play(correct, 1, 1, 0, 0, 1);
				 
				//Toast.makeText(getAppl icationContext(), "you hit pig" , Toast.LENGTH_SHORT).show();
			//	 int fores = generator.nextInt(2);
			//	 fores++;
				 
				  
				 v.setBackgroundResource(mImageIds[randomIndex]);
				 v.setOnClickListener(this);
				
			//	 for (int br = 0 ; br<fores; br++)
			//	 {
						 int stiles = generator.nextInt(numcols);
						 int grammes = generator.nextInt(numrows);
					
						 im[grammes][stiles].setBackgroundResource(R.drawable.fish);
						 im[grammes][stiles].setOnClickListener(this);
						 im[grammes][stiles].setTag("fish");
				
			//	 }
			}
			 else 
				{ points = points - 2 ;
			     Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
				}
	
			}
		if(tag!=null && tag.equals("fish2"))
		{
			
			points = points - 2;
			Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
			 //v.setBackgroundResource(mImageIds[randomIndex]);
			 //v.setOnClickListener(this);
			
		}
		if(tag!=null && tag.equals("fish3"))
		{
			Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
			points = points - 2;
			 //v.setBackgroundResource(mImageIds[randomIndex]);
			 v.setOnClickListener(this);
			
		}
		if(tag!=null && tag.equals("gorilla"))
		{
			
			points = points - 2;
			Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
			 //v.setBackgroundResource(mImageIds[randomIndex]);
			 v.setOnClickListener(this);
			
		}
		if(tag!=null && tag.equals("hamster"))
		{
			
			points = points - 2;
			Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
			 //v.setBackgroundResource(mImageIds[randomIndex]);
			 v.setOnClickListener(this);
			
		}
		if(tag!=null && tag.equals("hippo2"))
		{
			
			points = points - 2;
			Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
			 //v.setBackgroundResource(mImageIds[randomIndex]);
			 v.setOnClickListener(this);
			
		}
		if(tag!=null && tag.equals("lion"))
		{
			
			points = points - 2;
			Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
			 //v.setBackgroundResource(mImageIds[randomIndex]);
			 v.setOnClickListener(this);
			
		}
		if(tag!=null && tag.equals("panda"))
		{
			if (animaloption == 5)
			{
			
			//showCustomToast();
			
			 points = points + 10 ;
			 sp.play(correct, 1, 1, 0, 0, 1);
			 
			//Toast.makeText(getAppl icationContext(), "you hit pig" , Toast.LENGTH_SHORT).show();
			// int fores = generator.nextInt(2);
			// fores++;
			 
			  
			 v.setBackgroundResource(mImageIds[randomIndex]);
			 v.setOnClickListener(this);
			
			// for (int br = 0 ; br<fores; br++)
			// {
					 int stiles = generator.nextInt(numcols);
					 int grammes = generator.nextInt(numrows);
				
					 im[grammes][stiles].setBackgroundResource(R.drawable.panda);
					 im[grammes][stiles].setOnClickListener(this);
					 im[grammes][stiles].setTag("panda");
			
			// }
			
		
			}
			 else 
				{ points = points - 2 ;
			     Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
				}
	
			}
		
		if(tag!=null && tag.equals("penguin"))
		{
			
			points = points - 2;
			Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
			 //v.setBackgroundResource(mImageIds[randomIndex]);
			 v.setOnClickListener(this);
		}
		if(tag!=null && tag.equals("rooster"))
		{
			
			points = points - 2;
			Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
			 //v.setBackgroundResource(mImageIds[randomIndex]);
			 v.setOnClickListener(this);
			
		}
		if(tag!=null && tag.equals("seaturtle"))
		{
			
			points = points - 2;
			 //v.setBackgroundResource(mImageIds[randomIndex]);
			 v.setOnClickListener(this);
			
		}
		if(tag!=null && tag.equals("shark")) 
		{
			if (animaloption == 6)
			{	
				//showCustomToast();
			
			 points = points + 10 ;
			 sp.play(correct, 1, 1, 0, 0, 1);
			 
			//Toast.makeText(getAppl icationContext(), "you hit pig" , Toast.LENGTH_SHORT).show();
			// int fores = generator.nextInt(2);
			// fores++;
			 
			  
			 v.setBackgroundResource(mImageIds[randomIndex]);
			 v.setOnClickListener(this);
			
			// for (int br = 0 ; br<fores; br++)
			// {
					 int stiles = generator.nextInt(numcols);
					 int grammes = generator.nextInt(numrows);
				
					 im[grammes][stiles].setBackgroundResource(R.drawable.shark);
					 im[grammes][stiles].setOnClickListener(this);
					 im[grammes][stiles].setTag("shark");
			
			// }
			}
			 else 
				{ points = points - 2 ;
			     Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
				}
	
			}
		
		
		if(tag!=null && tag.equals("sheep"))
		{
			
			points = points - 2;
			Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
			 //v.setBackgroundResource(mImageIds[randomIndex]);
			 v.setOnClickListener(this);
			
		}
		if(tag!=null && tag.equals("turtle"))
		{
			
			 points = points - 2;
			 Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
			 //v.setBackgroundResource(mImageIds[randomIndex]);
			 v.setOnClickListener(this);
			
		}
		
		
		switch (mImageIds[randomIndex]){
		case R.drawable.pig:
			v.setTag("pig");
			break;
		case R.drawable.frog:
			v.setTag("frog");
			break;
		case R.drawable.elephant:
			v.setTag("elephant");
			break;
		case R.drawable.fish:
			v.setTag("fish");
			break;
		case R.drawable.dog:
			v.setTag("dog");
			break;
		case R.drawable.beaver:
			v.setTag("beaver");
			break;
		case R.drawable.bird:
			v.setTag("bird");
			break;
		case R.drawable.bug:
			v.setTag("bug");
			break;
		case R.drawable.cat:
			v.setTag("cat");
			break;
		case R.drawable.dolphin:
			v.setTag("dolphin");
			break;
		case R.drawable.fish2:
			v.setTag("fish2");
			break;
		case R.drawable.fish3:
			v.setTag("fish3");
			break;
		case R.drawable.gorilla:
			v.setTag("gorilla");
			break;
		case R.drawable.hamster:
			v.setTag("hamster");
			break;
		case R.drawable.hippo2:
			v.setTag("hippo2");
			break;
		case R.drawable.lion:
			v.setTag("lion");
			break;
		case R.drawable.panda:
			v.setTag("panda");
			break;
		case R.drawable.penguin:
			v.setTag("penguin");
			break;
		case R.drawable.rooster:
			v.setTag("rooster");
			break;
		case R.drawable.seaturtle:
			v.setTag("seaturtle");
			break;
		case R.drawable.shark:
			v.setTag("shark");
			break;
		case R.drawable.sheep:
			v.setTag("sheep");
			break;
		case R.drawable.turtle:
			v.setTag("turtle");
			break;
		
			
		}
	}





	private void showCustomToast() {
		// TODO Auto-generated method stub
		Toast mytoast = new Toast(this);
		mytoast.setDuration(50);
		mytoast.setGravity(Gravity.CENTER, 0, 0);
		
		
		LayoutInflater inflater = getLayoutInflater();
		View appearence = inflater.inflate(R.layout.toast_layout, (ViewGroup)findViewById(R.id.root));
		mytoast.setView(appearence);
		mytoast.show();
	}
	
	
	public void replaceEndwithD(View v) //play again
	{
		finish();
	}
 
	public void MainMenu(View v) // exit
	{
	
	    Intent intent = new Intent(this, MainActivity.class);
	    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivity(intent);
		
		
		
	}




	
	/*public void onItemClick(AdapterView<?> parent, View view, int k,long id) {
		// TODO Auto-generated method stub
		
	
		
	}*/
}

