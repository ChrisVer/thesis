package com.example.ptyx2;

import android.support.v7.app.ActionBarActivity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.nfc.tech.TagTechnology;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

public class HighScoresActivity extends ActionBarActivity {
	
	public static final String DEFAULT="N/A";
	
	TextView passTxtview , userNameTxtview;

	 TextView thirdTxt, fourthTxt;
	 
	 int clear = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_high_scores);
		
		/*requestWindowFeature( Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);*/
		
		userNameTxtview = (TextView) findViewById(R.id.high);
		passTxtview = (TextView) findViewById(R.id.high2);
		
		thirdTxt = (TextView) findViewById(R.id.high3);
		fourthTxt = (TextView) findViewById(R.id.high4);

		
		
		SharedPreferences sharedPreferences = getSharedPreferences("MyData", 0);
		String name = sharedPreferences.getString("high1", "");
		String password = sharedPreferences.getString("high2", "");
		String third = sharedPreferences.getString("high3", "");
		String fourth = sharedPreferences.getString("high4", "");
		
		
		
		if(name.equals(DEFAULT))//|| password.equals(DEFAULT))
		{
			Toast.makeText(this, "NO Data was found", Toast.LENGTH_LONG).show();
		}
		else 
		{
			Toast.makeText(this, "Data was LOADED ", Toast.LENGTH_LONG).show();
			userNameTxtview.setText(name);
			passTxtview.setText(password);
			//thirdTxt.setText(third);
			//fourthTxt.setText(fourth);
		}
		//passTxtview = (TextView) findViewById(R.id.textView2);
		
		
		
			
			
		
		
	}
	
	
	/*public void load(View view) {
		
		
	}*/

	/*public void previous(View view)
	{
		Toast.makeText(this, "PREVIOUS", Toast.LENGTH_LONG).show();
		Intent intent = new Intent(this, MainActivity.class);
		startActivity(intent);
		
	}*/
	
	public void MainMenu(View v) // exit
	{
	
		
	    Intent intent = new Intent(this, MainActivity.class);
	    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	    startActivity(intent);
		
		
		
	}
	
	public void clear(View v)
	{
		
		Intent theintent = new Intent(this, Easy.class);
	    theintent.putExtra("name",(int) 1);
	    startActivity(theintent);
		//Toast.makeText(this, "CLEAR DATA   ", Toast.LENGTH_LONG).show();
		
		
		
	}
	
}

