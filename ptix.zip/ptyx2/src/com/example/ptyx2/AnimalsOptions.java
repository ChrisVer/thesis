package com.example.ptyx2;

import android.app.Dialog;
import android.app.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;

import android.view.ViewGroup;

import android.widget.Button;
import android.widget.ImageView;


public class AnimalsOptions extends Fragment implements OnClickListener {

	ImageView pig , shark;
	
	 String option;
	
	 @Override
	public View onCreateView  (LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		//return super.onCreateView(inflater, container, savedInstanceState);
		
		 
		 View v= inflater.inflate(R.layout.options_layout,  container, false);
		 
		 /*pig = (ImageView) findViewById(R.id.pig1);
			shark = (ImageView) findViewById(R.id.shark1);
			
			pig.setOnClickListener(this);
			shark.setOnClickListener(this);*/
	 
		 return v;
	 }

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}

	
	 	
	 }
