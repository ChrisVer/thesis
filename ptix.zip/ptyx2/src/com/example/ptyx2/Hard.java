package com.example.ptyx2;

import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import javax.xml.transform.Templates;

import android.R.anim;
import android.R.string;
import android.support.v7.app.ActionBarActivity;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.media.AudioManager;
import android.media.Image;
import android.media.MediaPlayer;
import android.media.SoundPool;
import android.opengl.Visibility;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Base64;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.CorrectionInfo;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class Hard extends ActionBarActivity  implements OnClickListener
{
	
	
	
	int areTown = 0;
	int areForest = 0;
	int areJungle = 0;
	int areSea = 0;
	int areFarm = 0;
	
	MediaPlayer mp ;
	
	
	 SoundPool sp;
	 
	int placeoption = 0; // random animal place choice

	android.app.FragmentManager mymanager;
	
	TextView xronos, pointstext;
	
	GridView myGrid;
	
	private static final String FORMAT = "%02d:%02d";
	
	int seconds , minutes, k, i = 0, points = 0;
	
	ImageView test2,pig,fish;
	
	int correct =0;
	//ImageView[] test2;
	
	
	
	private static final Random rgenerator = new Random();

	private static final Integer[] mImageIds = 
	    { 
		 
		
		R.drawable.beaver,
		R.drawable.bird,
		R.drawable.bug,
		
		R.drawable.cat,
		
		R.drawable.dog,
		R.drawable.dolphin,
		
		R.drawable.elephant, 
		
		R.drawable.fish,
		R.drawable.fish2,
		R.drawable.fish3,
		R.drawable.frog,
		
		R.drawable.gorilla,
		
		R.drawable.hamster,
		
		R.drawable.hippo2,
		
		R.drawable.lion,
		
		R.drawable.panda,
		R.drawable.penguin,
		R.drawable.pig,
		
		R.drawable.rooster,
		
		R.drawable.seaturtle,
		R.drawable.shark,
		R.drawable.sheep,
		
		R.drawable.turtle
		};

	private static final int numrows = 3;

	private static final int numcols = 6;
	
	Random generator = new Random();
	
	int gourounia = 0, psaria =0 , elef = 0 , batr = 0 , skil = 0 ;
	
	int[][] pinakas = new int[3][6];
	TableLayout table;
	ImageView im[][] =  new ImageView[3][6];
	 
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		requestWindowFeature( Window.FEATURE_NO_TITLE);
		getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
		
		setContentView(R.layout.activity_medium);
		
		mp = MediaPlayer.create(this, R.raw.correct_midhigh);
		
		
		sp = new SoundPool(5, AudioManager.STREAM_MUSIC, 0);
		correct = sp.load(this, R.raw.correct_midhigh, 1);
		
		
		mymanager = getFragmentManager();
		
	
		pointstext=(TextView)findViewById(R.id.textView2);
		
		 table = (TableLayout) findViewById(R.id.table);
		
		for (int row = 0; row <numrows; row ++)
		{
			TableRow tablerow = new TableRow(this);
			table.addView(tablerow);
			
			for (int col = 0; col<numcols;col++)
			{
				 
				 int randomIndex = generator.nextInt(mImageIds.length);
				 im[row][col] = new ImageView(this);
				 im[row][col].setBackgroundResource(mImageIds[randomIndex]);
				 im[row][col].setOnClickListener(this);
				 
				 
			     tablerow.addView(im[row][col]);
				 
			     if (mImageIds[randomIndex] == R.drawable.beaver) 
				 {	 
			    	 im[row][col].setTag("forest");
			    	 areForest++;
				 }
			     if (mImageIds[randomIndex] == R.drawable.bird) 
				 {	 
			    	 im[row][col].setTag("farm");
			    	 areFarm++;
				 }
			     if (mImageIds[randomIndex] == R.drawable.bug) 
				 {	 
			    	 im[row][col].setTag("forest");
			    	 areForest++;
				 }
			     if (mImageIds[randomIndex] == R.drawable.cat) 
				 {	 
			    	 im[row][col].setTag("town");
			    	 areTown++;
				 }
			     if (mImageIds[randomIndex] == R.drawable.dolphin) 
				 {	 
			    	 im[row][col].setTag("sea");
			    	 areSea++;
				 }
			     if (mImageIds[randomIndex] == R.drawable.fish2) 
				 {	 
			    	 im[row][col].setTag("sea");
			    	 areSea++;
				 }
			     if (mImageIds[randomIndex] == R.drawable.fish3) 
				 {	 
			    	 im[row][col].setTag("sea");
			    	 areSea++;
				 }
			     if (mImageIds[randomIndex] == R.drawable.gorilla) 
				 {	 
			    	 im[row][col].setTag("jungle");
			    	 areJungle++;
				 }
			     if (mImageIds[randomIndex] == R.drawable.hamster) 
				 {	 
			    	 im[row][col].setTag("town");
			    	 areTown++;
				 }
			     if (mImageIds[randomIndex] == R.drawable.hippo2) 
				 {	 
			    	 im[row][col].setTag("jungle");
			    	 areJungle++;
				 }
			     if (mImageIds[randomIndex] == R.drawable.lion) 
				 {	 
			    	 im[row][col].setTag("jungle");
			    	 areJungle++;
				 }
			     if (mImageIds[randomIndex] == R.drawable.panda) 
				 {	 
			    	 im[row][col].setTag("forest");	
			    	 areForest++;
				 }
			     if (mImageIds[randomIndex] == R.drawable.penguin) 
				 {	 
			    	 im[row][col].setTag("sea");
			    	 areSea++;
				 }
			     if (mImageIds[randomIndex] == R.drawable.rooster) 
				 {	 
			    	 im[row][col].setTag("farm");
			    	 areFarm++;
				 }
			     if (mImageIds[randomIndex] == R.drawable.seaturtle) 
				 {	 
			    	 im[row][col].setTag("sea");
			    	 areSea++;
				 }
			     if (mImageIds[randomIndex] == R.drawable.shark) 
				 {	 
			    	 im[row][col].setTag("sea");
			    	 areSea++;
				 }
			     if (mImageIds[randomIndex] == R.drawable.sheep) 
				 {	 
			    	 im[row][col].setTag("farm");
			    	 areFarm++;
				 }
			     if (mImageIds[randomIndex] == R.drawable.turtle) 
				 {	 
			    	 im[row][col].setTag("forest");
			    	 areForest++;
				 }
			     
			//------------------------------------------------------------------------     
			     
			    
			     if (mImageIds[randomIndex] == R.drawable.pig) 
				 {	 
			    	 
			    	 im[row][col].setTag("farm");
			    	 areFarm++;
				 }
				 if (mImageIds[randomIndex] == R.drawable.fish) 
				 {	 
					 im[row][col].setTag("sea");
					 areSea++;
				 }
				 if (mImageIds[randomIndex] == R.drawable.elephant) 
				 {	 
					 im[row][col].setTag("jungle");
					 areJungle++;
				 }
				 if (mImageIds[randomIndex] == R.drawable.frog) 
				 {	
					 im[row][col].setTag("town");
					 areTown++;
				 }
				 if (mImageIds[randomIndex] == R.drawable.dog) 
				 {	
					 im[row][col].setTag("town");
					 areTown++;
				 }
				 
				 
				 	
		   
		       }// for loop
  	
	        }
		
		xronos=(TextView)findViewById(R.id.textView1);
		 
		 new CountDownTimer(10000, 1000) { // adjust the milli seconds here

		        public void onTick(long millisUntilFinished) 
		        {

						        	xronos.setText(""+String.format(FORMAT,
						                    
						TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished) - TimeUnit.HOURS.toMinutes(
						                    TimeUnit.MILLISECONDS.toHours(millisUntilFinished)),
						  TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) - TimeUnit.MINUTES.toSeconds(
						                      TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished))));    
						        	
						        	
						        	
		        }

		        public void onFinish() {
		        	//xronos.setText();
		        	
		        	pointstext.setText(String.valueOf(points));
		        	pointstext.setVisibility(View.GONE);
		        	
		        	table.removeAllViewsInLayout();
		        	
		        	mymanager = getFragmentManager();
		        	End e1 = new End();
		    		FragmentTransaction transaction2 = mymanager.beginTransaction();
		    		transaction2.add(R.id.group2, e1, "end");
		    		transaction2.commit();
		    		
		        		        	
		        }
		     }.start(); 
		     
		     // -------- kodikas pou ekteleitai asxeta apo ti n epilogi toy xristi
		     
		     
		     
		     // -------- kodikas poy ekteleitai analoga me ti epilexthike
		
		     
		     
		    placeoption = generator.nextInt(4);
		     
		    
		      
		     // 0 = town , 1 = forest , 2 = jungle, 3 = sea, 4 = farm
		     
		if (placeoption == 0) // an epilexthike na psaxnv gia town animals     
		{ 
			Toast.makeText(getApplicationContext(), "Who lives in the TOWN ?" , Toast.LENGTH_SHORT).show();
			
			// se periptosi poy arxika den exei sxediastei kanena TOWN ANIMAL
			
			if (areTown == 0)
				{
					int stiles = generator.nextInt(numcols);
					int grammes = generator.nextInt(numrows);
					
					 im[grammes][stiles].setBackgroundResource(R.drawable.dog);
					 im[grammes][stiles].setOnClickListener(this);
					 im[grammes][stiles].setTag("town");
				}
			
		}
		
		if (placeoption == 1) // an epilexthe na psaxnv forest animals
		{
			Toast.makeText(getApplicationContext(), "Who lives in the FOREST ?" , Toast.LENGTH_SHORT).show();
			
			// se periptosi poy arxika den exei sxediastei kanena fish
			
			if (areForest == 0)
			{
				int stiles = generator.nextInt(numcols);
				int grammes = generator.nextInt(numrows);
				
				 im[grammes][stiles].setBackgroundResource(R.drawable.beaver);
				 im[grammes][stiles].setOnClickListener(this);
				 im[grammes][stiles].setTag("forest");
			}
			
			
		}
	
		if (placeoption == 2) // an epilexthike na psaxnv gia jungle animals     
		{ 
			Toast.makeText(getApplicationContext(), "Who lives in the JUNGLE ?" , Toast.LENGTH_SHORT).show();
			 
			// se periptosi poy arxika den exei sxediastei kanena elephant
			
			if (areJungle == 0)
				{
					int stiles = generator.nextInt(numcols);
					int grammes = generator.nextInt(numrows);
					
					 im[grammes][stiles].setBackgroundResource(R.drawable.elephant);
					 im[grammes][stiles].setOnClickListener(this);
					 im[grammes][stiles].setTag("jungle");
				}
		}
		
		if (placeoption == 3) // an epilexthike na psaxnv gia sea animals     
		{ 
			Toast.makeText(getApplicationContext(), "Who lives under the SEA ?" , Toast.LENGTH_SHORT).show();
			 
			// se periptosi poy arxika den exei sxediastei kanena elephant
			
			if (areSea == 0)
				{
					int stiles = generator.nextInt(numcols);
					int grammes = generator.nextInt(numrows);
					
					 im[grammes][stiles].setBackgroundResource(R.drawable.shark);
					 im[grammes][stiles].setOnClickListener(this);
					 im[grammes][stiles].setTag("sea");
				}
		}
		
		
		if (placeoption == 4) // an epilexthike na psaxnv gia farm animals     
		{ 
			Toast.makeText(getApplicationContext(), "Who lives in the FARM ?" , Toast.LENGTH_SHORT).show();
			 
			// se periptosi poy arxika den exei sxediastei kanena elephant
			
			if (areFarm == 0)
				{
					int stiles = generator.nextInt(numcols);
					int grammes = generator.nextInt(numrows);
					
					 im[grammes][stiles].setBackgroundResource(R.drawable.rooster);
					 im[grammes][stiles].setOnClickListener(this);
					 im[grammes][stiles].setTag("farm");
				}
		}
		

}//onCreate
	
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.easy, menu);
		
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}




	@Override
	public void onClick(View v ) {
		
		
		String tag =(String)v.getTag();
		int randomIndex = generator.nextInt(mImageIds.length);
		/*if (mp.isPlaying())
			{
				mp.stop();
				
			}
		
			
		mp.start();*/
		
			

		if(tag!=null && tag.equals("town")) // an patiseis town animal
		{
			//Toast.makeText(getApplicationContext(), " TOWN !" , Toast.LENGTH_SHORT).show();
			
			if (placeoption == 0) // an prepei na breis town animals tha pareis 10 points
			 
			{  //showCustomToast();
			
			 points = points + 10 ;
			 if (correct != 0) 
				{
					sp.play(correct, 1, 1, 0, 0, 1);
				}
			 
			 //mp.start();
			 //mp.stop();
			
			//Toast.makeText(getAppl icationContext(), "you hit pig" , Toast.LENGTH_SHORT).show();
			int fores = generator.nextInt(2);
			 fores++;
			 
			  
			 v.setBackgroundResource(mImageIds[randomIndex]); // tha mpei sti thesi tou ena random zoo
			 v.setOnClickListener(this);
			
			 for (int br = 0 ; br<fores; br++)
			    {
					 int stiles = generator.nextInt(numcols);
					 int grammes = generator.nextInt(numrows);
					 
					 if (br == 0)
					 {	 	
						im[grammes][stiles].setBackgroundResource(R.drawable.hamster);
					 	im[grammes][stiles].setOnClickListener(this);
					 	im[grammes][stiles].setTag("town");
					 }
					 else
					 {	 	
							im[grammes][stiles].setBackgroundResource(R.drawable.shark);
						 	im[grammes][stiles].setOnClickListener(this);
						 	im[grammes][stiles].setTag("sea");
					 }
			     }
		    }
			else  // allios an den prepei na breiw town animals , kai esy patiseiw town animals , tha xaseiw 2 pontoys
				{ 
				    points = points - 2 ;
			        Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
				}
			
			
		}
		
		
		if(tag!=null && tag.equals("forest")) // an patiseis town animal
		{
			//Toast.makeText(getApplicationContext(), " FOREST !" , Toast.LENGTH_SHORT).show();
			
			if (placeoption == 1) // an prepei na breis town animals tha pareis 10 points
			
			{  //showCustomToast();
			
			 points = points + 10 ;
			 if (correct != 0) 
				{
					sp.play(correct, 1, 1, 0, 0, 1);
				}
			 //mp.start();
			// mp.stop();
			//Toast.makeText(getAppl icationContext(), "you hit pig" , Toast.LENGTH_SHORT).show();
			 int fores = generator.nextInt(3);
			 fores++;
			 
			  
			 v.setBackgroundResource(mImageIds[randomIndex]); // tha mpei sti thesi tou ena random zoo
			 v.setOnClickListener(this);
			
			 for (int br = 0 ; br<fores; br++)
			   {
					 int stiles = generator.nextInt(numcols);
					 int grammes = generator.nextInt(numrows);
				
					 if (br == 0)
					 {	 	
						im[grammes][stiles].setBackgroundResource(R.drawable.turtle);
					 	im[grammes][stiles].setOnClickListener(this);
					 	im[grammes][stiles].setTag("forest");
					 }
					 else if (br == 1)
					 {	 	
							im[grammes][stiles].setBackgroundResource(R.drawable.bug);
						 	im[grammes][stiles].setOnClickListener(this);
						 	im[grammes][stiles].setTag("forest");
					 }
					 else if (br == 2)
					 {	 	
							im[grammes][stiles].setBackgroundResource(R.drawable.pig);
						 	im[grammes][stiles].setOnClickListener(this);
						 	im[grammes][stiles].setTag("farm");
					 }
			
			}
		    }
			else  // allios an den prepei na breiw town animals , kai esy patiseiw town animals , tha xaseiw 2 pontoys
				{ 
				    points = points - 2 ;
			        Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
				}
			
			
		}
		
			
		if(tag!=null && tag.equals("jungle")) // an patiseis town animal
		{
			//Toast.makeText(getApplicationContext(), " JUNGLE !" , Toast.LENGTH_SHORT).show();
			
			if (placeoption == 2) // an prepei na breis town animals tha pareis 10 points
			
			{  //showCustomToast();
			
			 points = points + 10 ;
			 if (correct != 0) 
				{
					sp.play(correct, 1, 1, 0, 0, 1);
				}
			 //mp.start();
			 //mp.stop();
			//Toast.makeText(getAppl icationContext(), "you hit pig" , Toast.LENGTH_SHORT).show();
			 int fores = generator.nextInt(3);
			 fores++;
			 
			  
			 v.setBackgroundResource(mImageIds[randomIndex]); // tha mpei sti thesi tou ena random zoo
			 v.setOnClickListener(this);
			
		    for (int br = 0 ; br<fores; br++)
			  {
					 int stiles = generator.nextInt(numcols);
					 int grammes = generator.nextInt(numrows);
				
					 if (br == 0)
					 {	 	
						im[grammes][stiles].setBackgroundResource(R.drawable.hippo2);
					 	im[grammes][stiles].setOnClickListener(this);
					 	im[grammes][stiles].setTag("jungle");
					 }
					 else if (br == 1)
					 {	 	
						im[grammes][stiles].setBackgroundResource(R.drawable.elephant);
					 	im[grammes][stiles].setOnClickListener(this);
					 	im[grammes][stiles].setTag("jungle");
					 }
					 else if (br == 2)
 					 {	 	
							im[grammes][stiles].setBackgroundResource(R.drawable.seaturtle);
						 	im[grammes][stiles].setOnClickListener(this);
						 	im[grammes][stiles].setTag("sea");
					 }
			
			   }
		    }
			else  // allios an den prepei na breiw town animals , kai esy patiseiw town animals , tha xaseiw 2 pontoys
				{ 
				    points = points - 2 ;
			        Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
				}
			
			
		}
			 
		
		  
		
		if(tag!=null && tag.equals("sea")) // an patiseis town animal
		{
			//Toast.makeText(getApplicationContext(), " SEA !" , Toast.LENGTH_SHORT).show();
			
			if (placeoption == 3) // an prepei na breis town animals tha pareis 10 points
			
			{  
				//showCustomToast();
			
			 points = points + 10 ;
			 if (correct != 0) 
				{
					sp.play(correct, 1, 1, 0, 0, 1);
				}
			 //mp.start();
			 //mp.stop();
			//Toast.makeText(getAppl icationContext(), "you hit pig" , Toast.LENGTH_SHORT).show();
			int fores = generator.nextInt(3);
			 fores++;
			 
			  
			 v.setBackgroundResource(mImageIds[randomIndex]); // tha mpei sti thesi tou ena random zoo
			 v.setOnClickListener(this);
			
			for (int br = 0 ; br<fores; br++)
			 {
					 int stiles = generator.nextInt(numcols);
					 int grammes = generator.nextInt(numrows);
				
					 if (br == 0)
					 {	 	
						im[grammes][stiles].setBackgroundResource(R.drawable.fish2);
					 	im[grammes][stiles].setOnClickListener(this);
					 	im[grammes][stiles].setTag("sea");
					 }
					 if (br == 1)
					 {	 	
						im[grammes][stiles].setBackgroundResource(R.drawable.dolphin);
					 	im[grammes][stiles].setOnClickListener(this);
					 	im[grammes][stiles].setTag("sea");
					 }
					 else if (br == 2)
					 {	 	
							im[grammes][stiles].setBackgroundResource(R.drawable.frog);
						 	im[grammes][stiles].setOnClickListener(this);
						 	im[grammes][stiles].setTag("town");
					 }
			
			}
		    }
			else  // allios an den prepei na breiw town animals , kai esy patiseiw town animals , tha xaseiw 2 pontoys
				{ 
				    points = points - 2 ;
			        Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
				}
			
			
		}
		
		
		if(tag!=null && tag.equals("farm")) // an patiseis town animal
		{
			//Toast.makeText(getApplicationContext(), " FARM !" , Toast.LENGTH_SHORT).show();
			
			if (placeoption == 4) // an prepei na breis town animals tha pareis 10 points
			
			{  //showCustomToast();
			
			 points = points + 10 ;
			 if (correct != 0) 
				{
					sp.play(correct, 1, 1, 0, 0, 1);
				}
			 //mp.start();
			 //mp.stop();
			
			//Toast.makeText(getAppl icationContext(), "you hit pig" , Toast.LENGTH_SHORT).show();
			 int fores = generator.nextInt(3);
			 fores++;
			 
			  
			 v.setBackgroundResource(mImageIds[randomIndex]); // tha mpei sti thesi tou ena random zoo
			 v.setOnClickListener(this);
			
			 for (int br = 0 ; br < fores; br++)
			     {
					 int stiles = generator.nextInt(numcols);
					 int grammes = generator.nextInt(numrows);
					 
					 if (br == 0)
					 {
						 im[grammes][stiles].setBackgroundResource(R.drawable.rooster);
						 im[grammes][stiles].setOnClickListener(this);
						 im[grammes][stiles].setTag("farm");
					 }
					 else if (br == 1)
					 {
						 im[grammes][stiles].setBackgroundResource(R.drawable.pig);
						 im[grammes][stiles].setOnClickListener(this);
						 im[grammes][stiles].setTag("farm");
					 }
					 else 
					 {
						 im[grammes][stiles].setBackgroundResource(R.drawable.lion);
						 im[grammes][stiles].setOnClickListener(this);
					 	 im[grammes][stiles].setTag("jungle");
					 }	
			     }
		    }
			else  // allios an den prepei na breiw town animals , kai esy patiseiw town animals , tha xaseiw 2 pontoys
				{ 
				    points = points - 2 ;
			        Toast.makeText(getApplicationContext(), "- 2 Points !   " , Toast.LENGTH_SHORT).show();
				}
			
			
		}
		
		
		
		
		switch (mImageIds[randomIndex]){
		case R.drawable.pig:
			v.setTag("farm");
			break;
		case R.drawable.frog:
			v.setTag("town");
			break;
		case R.drawable.elephant:
			v.setTag("jungle");
			break;
		case R.drawable.fish:
			v.setTag("sea");
			break;
		case R.drawable.dog:
			v.setTag("town");
			break;
		case R.drawable.beaver:
			v.setTag("forest");
			break;
		case R.drawable.bird:
			v.setTag("forest");
			break;
		case R.drawable.bug:
			v.setTag("forest");
			break;
		case R.drawable.cat:
			v.setTag("town");
			break;
		case R.drawable.dolphin:
			v.setTag("sea");
			break;
		case R.drawable.fish2:
			v.setTag("sea");
			break;
		case R.drawable.fish3:
			v.setTag("sea");
			break;
		case R.drawable.gorilla:
			v.setTag("jungle");
			break;
		case R.drawable.hamster:
			v.setTag("town");
			break;
		case R.drawable.hippo2:
			v.setTag("jungle");
			break;
		case R.drawable.lion:
			v.setTag("jungle");
			break;
		case R.drawable.panda:
			v.setTag("forest");
			break;
		case R.drawable.penguin:
			v.setTag("sea");
			break;
		case R.drawable.rooster:
			v.setTag("farm");
			break;
		case R.drawable.seaturtle:
			v.setTag("sea");
			break;
		case R.drawable.shark:
			v.setTag("sea");
			break;
		case R.drawable.sheep:
			v.setTag("farm");
			break;
		case R.drawable.turtle:
			v.setTag("forest");
			break;
		
			
		}
	}





	private void showCustomToast() {
		// TODO Auto-generated method stub
		Toast mytoast = new Toast(this);
		mytoast.setDuration(50);
		mytoast.setGravity(Gravity.CENTER, 0, 0);
		
		
		LayoutInflater inflater = getLayoutInflater();
		View appearence = inflater.inflate(R.layout.toast_layout, (ViewGroup)findViewById(R.id.root));
		mytoast.setView(appearence);
		mytoast.show();
	}
	
	
	public void replaceEndwithD(View v) //play again
	{
		finish();
	}
 
	public void MainMenu(View v) // exit
	{
	
		
	    Intent intent = new Intent(this, MainActivity.class);
	    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	    startActivity(intent);
		
		
		
	}




	
	/*public void onItemClick(AdapterView<?> parent, View view, int k,long id) {
		// TODO Auto-generated method stub
		
	
		
	}*/
}


